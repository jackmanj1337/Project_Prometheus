#!/usr/bin/env node

import { createServer } from "node:http";
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

import * as bridge from "../../../../tools/playwright/lib/bridge.mjs";
import {
  assertClipAwareBridge, clickableEntries, clickControl, CLIP_AWARE_QUERY,
} from "../../../../tools/playwright/lib/clicks.mjs";
import { boot, settle, teardown } from "../../../../tools/playwright/lib/harness.mjs";

const TIMEOUT_MS = 45_000;

// Two different saves, and the difference is the whole reason this second mode
// exists. `mid-map` begins the map and saves from the battle menu, which produces a
// SUSPEND save: the map is live, so loading it resumes the battle and Prep never
// appears. `between-map` saves from Prep BEFORE Begin — PrepScreen budgets that slot
// as "between_map" — so loading it lands in Prep, and a free-roam campaign's Prep is
// the only place a Return to Campaign Map control exists. The stateful prep-return
// journey needs the second one; the 2026-09-06 drive produced the first, which is why
// that journey stayed open recording a fixture limitation rather than passing.
const MODES = ["mid-map", "between-map"];
const MIME = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".wasm": "application/wasm",
  ".pck": "application/octet-stream", ".png": "image/png", ".json": "application/json",
};

function usage(message) {
  if (message) console.error(`error: ${message}`);
  console.error(
    "Usage: manual-free-roam-save.mjs --web-export DIR --pack ZIP --out DIR [--campaign ID] " +
      `[--mode ${MODES.join("|")}] [--viewport WxH]`,
  );
  return 2;
}

function parseArgs(argv) {
  const options = {
    webExport: null, pack: null, out: null, campaign: "proving_grounds", port: 0,
    mode: "mid-map",
    // The measured floor is 800x600 (run.mjs's three matrices), so a fixture built here
    // can now be built at the size the gate measures. The default stays at the size every
    // existing fixture was built at: changing it silently would make two fixtures with the
    // same name incomparable.
    viewport: { width: 1280, height: 720 }, resizeAfterStart: null, contentScale: "1", menuScale: "1",
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const next = () => {
      if (!argv[i + 1]) throw new Error(`${arg} requires a value`);
      return argv[++i];
    };
    if (arg === "--web-export") options.webExport = path.resolve(next());
    else if (arg === "--pack") options.pack = path.resolve(next());
    else if (arg === "--out") options.out = path.resolve(next());
    else if (arg === "--campaign") options.campaign = next();
    else if (arg === "--content-scale") options.contentScale = next();
    else if (arg === "--resize-after-start") { const m = /^(\d+)x(\d+)$/.exec(next()); if (!m) throw new Error("--resize-after-start must be WxH"); options.resizeAfterStart = { width: Number(m[1]), height: Number(m[2]) }; }
    else if (arg === "--menu-scale") options.menuScale = next();
    else if (arg === "--mode") options.mode = next();
    else if (arg === "--port") options.port = Number(next());
    else if (arg === "--viewport") {
      const match = /^(\d+)x(\d+)$/.exec(next());
      if (!match) throw new Error("--viewport must be WxH");
      options.viewport = { width: Number(match[1]), height: Number(match[2]) };
    }
    else if (arg === "--help" || arg === "-h") return { help: true };
    else throw new Error(`unknown argument: ${arg}`);
  }
  if (!options.webExport) throw new Error("--web-export is required");
  if (!options.pack) throw new Error("--pack is required");
  if (!options.out) throw new Error("--out is required");
  if (!MODES.includes(options.mode)) {
    throw new Error(`--mode must be one of ${MODES.join(", ")}`);
  }
  return options;
}

async function serve(directory, port, contentScale, menuScale) {
  const server = createServer((request, response) => {
    const requested = decodeURIComponent(new URL(request.url, "http://localhost").pathname);
    const relative = requested === "/" ? "index.html" : requested.replace(/^\/+/, "");
    const file = path.join(directory, relative);
    if (!file.startsWith(path.resolve(directory))) {
      response.writeHead(403).end();
      return;
    }
    const stream = createReadStream(file);
    stream.on("error", () => response.writeHead(404).end());
    stream.on("open", () => {
      response.writeHead(200, {
        "content-type": MIME[path.extname(file)] ?? "application/octet-stream",
        "cross-origin-opener-policy": "same-origin",
        "cross-origin-embedder-policy": "require-corp",
      });
      stream.pipe(response);
    });
  });
  await new Promise((resolve) => server.listen(port, "127.0.0.1", resolve));
  const address = server.address();
  return {
    url: `http://127.0.0.1:${address.port}/index.html?${new URLSearchParams({
      test_bridge: "1", ...CLIP_AWARE_QUERY, content_scale: contentScale, menu_scale: menuScale,
    })}`,
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}

// Every lookup here returns [controlPath, rect] rather than a bare rect, because the
// path is what clickControl() needs: a bridge rect is the rect the control was LAID OUT
// at, so inside a ScrollContainer its centre can be a point the engine never hands to
// it, and only the ancestor chain says so. This ran only at 1280x720 for a year, where
// nothing it touches clips -- which is why it had never failed, not a reason it was safe.
// At 800x600 the Load Game row it exports from is 61px tall in a 43px scroll viewport.
function entryBySuffix(observed, suffix) {
  const matches = clickableEntries(observed).filter(([name]) => name.endsWith(suffix));
  if (matches.length !== 1) throw new Error(`expected exactly one visible ${suffix}, found ${matches.length}`);
  return matches[0];
}

// Optional by design: the callers below branch on whether a control is there at all
// (a battle menu has Save, a suspend-only menu does not), so a miss is null, not a throw.
function entryMatching(observed, predicate) {
  return clickableEntries(observed).find(([name, rect]) => predicate(name, rect)) ?? null;
}

async function clickSuffix(page, suffix, options = {}) {
  const observed = await bridge.snapshot(page);
  return clickControl(page, observed, entryBySuffix(observed, suffix)[0], options);
}

async function waitForScreen(page, screen) {
  await page.waitForFunction(
    ([name, expected]) => {
      try { return JSON.parse(window[name]?.state ?? "{}").screen === expected; } catch { return false; }
    },
    [bridge.BRIDGE_GLOBAL, screen],
    { timeout: TIMEOUT_MS },
  );
  await settle(page);
}

async function importPack(page, pack) {
  await waitForScreen(page, "main-menu");
  await clickSuffix(page, "/CampaignLibraryButton");
  await waitForScreen(page, "campaign-library");
  const chooser = page.waitForEvent("filechooser");
  await clickSuffix(page, "/BtnImport", { settleAfter: false });
  await (await chooser).setFiles(pack);
  await page.waitForFunction(
    (name) => {
      try {
        const state = JSON.parse(window[name]?.state ?? "{}");
        return Boolean(state.importResult?.outcome);
      } catch { return false; }
    },
    bridge.BRIDGE_GLOBAL,
    { timeout: TIMEOUT_MS },
  );
  const imported = await bridge.snapshot(page);
  await page.keyboard.press("Enter");
  await settle(page);
  await clickSuffix(page, "/BtnBack");
  await waitForScreen(page, "main-menu");
  return imported.importResult;
}

async function openCampaignLibraryControl(page, suffix, screen) {
  await waitForScreen(page, "main-menu");
  await clickSuffix(page, "/CampaignLibraryButton");
  await waitForScreen(page, "campaign-library");
  await clickSuffix(page, suffix);
  await waitForScreen(page, screen);
}

async function openLoadGame(page) {
  await openCampaignLibraryControl(page, "/BtnLoadGame", "load-game");
}

async function openNewGame(page) {
  await openCampaignLibraryControl(page, "/BtnNewGame", "new-game");
}

async function readEntries(page) {
  const observed = await bridge.snapshot(page);
  if (!observed.newGameEntries?.offered) throw new Error("New Game selector did not publish campaign entries");
  return observed.newGameEntries;
}

async function selectCampaign(page, campaignId) {
  const entries = await readEntries(page);
  const entry = entries.offered.find((candidate) => candidate.campaign_id === campaignId);
  if (!entry) throw new Error(`campaign ${campaignId} was not offered: ${JSON.stringify(entries.offered)}`);
  await clickSuffix(page, "/OptRun", { settleAfter: false });
  await page.waitForFunction(
    (name) => {
      try { return JSON.parse(window[name]?.state ?? "{}").newGameEntries?.popup?.visible === true; } catch { return false; }
    },
    bridge.BRIDGE_GLOBAL,
    { timeout: TIMEOUT_MS },
  );
  // NOT routed through clickControl, and it cannot be: an OptionButton's list is a
  // Godot PopupMenu in its own Window, outside the bridge's Control tree, so it has no
  // control path and no ancestors to intersect. The bridge publishes the popup's own
  // rect and item count instead, and a popup is never clipped by a scroll container --
  // it is placed on top of everything. Item pitch is the right maths here.
  const popup = (await readEntries(page)).popup;
  const pitch = popup.rect.h / popup.itemCount;
  await page.mouse.click(
    popup.rect.x + popup.rect.w / 2,
    popup.rect.y + (entry.index + 0.5) * pitch,
  );
  await settle(page);
  const selected = await readEntries(page);
  if (selected.selected !== entry.index) throw new Error(`campaign selector stopped at ${selected.selected}`);
  return entry;
}

async function saveAndExport(page, out) {
  const before = await bridge.snapshot(page);
  let menuState = before;
  let saveControl = entryMatching(menuState, (name) => /Save|save/i.test(name));
  if (!saveControl) {
    const detailBack = entryMatching(menuState, (name) => name.endsWith("/BtnBack"));
    if (detailBack) {
      menuState = await clickControl(page, menuState, detailBack[0]);
    }
    await page.keyboard.press("m");
    await settle(page);
    menuState = await bridge.snapshot(page);
    await page.screenshot({ path: path.join(out, "02-open-battle-menu.png") });
    await writeFile(path.join(out, "02-open-battle-menu.json"), `${JSON.stringify(menuState, null, 2)}\n`);
    saveControl = entryMatching(menuState, (name) => /Save|save/i.test(name));
  }
  const suspendControl = !saveControl
    && entryMatching(menuState, (name) => name.endsWith("/SuspendAndQuitButton"));
  if (suspendControl) {
    await clickControl(page, menuState, suspendControl[0]);
    await page.keyboard.press("Tab");
    await page.keyboard.press("Enter");
    await waitForScreen(page, "main-menu");
  }
  if (!saveControl) {
    if (!suspendControl) {
      throw new Error("live map and battle menu exposed no Save or Suspend control; manual save cannot proceed");
    }
  } else {
    const afterSave = await clickControl(page, menuState, saveControl[0]);
    await page.screenshot({ path: path.join(out, "03-save-dialog.png") });
    await writeFile(path.join(out, "03-save-dialog.json"), `${JSON.stringify(afterSave, null, 2)}\n`);
    const confirm = entryMatching(afterSave, (name) => /Save|Confirm/i.test(name));
    if (!confirm) throw new Error("save dialog opened but no save confirmation control was published");
    await clickControl(page, afterSave, confirm[0]);
  }
  if (saveControl) {
    await page.keyboard.press("Escape");
    await waitForScreen(page, "main-menu");
  }
  await openLoadGame(page);
  const loaded = await bridge.snapshot(page);
  const row = entryMatching(
    loaded, (name) => /Row_/.test(name) && /ExportButton/.test(name),
  );
  if (!row) throw new Error("saved campaign did not appear with an Export control");
  const downloadReady = page.waitForEvent("download");
  await clickControl(page, loaded, row[0], { settleAfter: false });
  const download = await downloadReady;
  const destination = path.join(out, "free-roam-launch-save.json");
  await download.saveAs(destination);
  const bytes = await readFile(destination);
  const identity = JSON.parse(bytes.toString("utf8"));
  const digest = createHash("sha256").update(bytes).digest("hex");
  await page.screenshot({ path: path.join(out, "04-load-game-export.png") });
  await writeFile(path.join(out, "04-load-game-export.json"), `${JSON.stringify({
    bridge: loaded,
    download: { path: destination, suggestedFilename: download.suggestedFilename(), bytes: bytes.length, sha256: digest },
    save: { campaign: identity.campaign, top_level_keys: Object.keys(identity).sort() },
  }, null, 2)}\n`);
  return { destination, bytes: bytes.length, sha256: digest, campaign: identity.campaign };
}

// Save from Prep, before the map is begun. One click: on a fresh library nothing
// shares the "<chapter> — Prep" label and the between_map budget is not full, so
// PrepScreen writes a new slot directly rather than opening its overwrite or
// replacement-picker dialog.
async function saveFromPrep(page, out) {
  await clickSuffix(page, "/SaveButton");
  // The canvas can leave focus on the pressed control while the native-style
  // dialog is being created. Enter is harmless when no dialog is present and
  // also confirms an overwrite when a prior fixture occupied the same label.
  await page.keyboard.press("Enter");
  // SaveStatus is an empty Label in the WebTestBridge snapshot even after a
  // successful write, so the durable proof is the exported slot below. Give
  // the write one frame to complete and assert that Prep stayed active.
  await page.waitForTimeout(250);
  const saved = await bridge.snapshot(page);
  if (saved.screen !== "prep" || !saved.activeCampaign?.campaignId) {
    throw new Error("Prep save did not leave a valid active campaign on the Prep screen");
  }
  await page.screenshot({ path: path.join(out, "02-prep-saved.png") });
  await writeFile(path.join(out, "02-prep-saved.json"), `${JSON.stringify(saved, null, 2)}\n`);
  return saved;
}

// The control the journey exists to exercise, verified through the route the journey
// takes rather than in this authoring session. Prep hides Return unless
// CampaignManager's prep navigation origin is "campaign_map", and starting a campaign
// from New Game sets it to "direct" — so the control is correctly absent here and its
// absence says nothing about the fixture. What makes the fixture work is
// MainMenu._continue_campaign: resuming a campaign that uses an overworld sets that
// origin to "campaign_map" before launching the node, so LOADING this save lands in a
// Prep that does offer Return. Asserting it any earlier would reject a good fixture.
async function assertFixtureReturnsToCampaignMap(page, slotId, out) {
  await openLoadGame(page);
  await clickSuffix(page, `/Row_${slotId}/LoadButton`);
  await waitForScreen(page, "prep");
  const prep = await bridge.snapshot(page);
  if (!Object.keys(prep?.rects ?? {}).some((name) => name.endsWith("/ReturnButton"))) {
    throw new Error(
      "the restored save's Prep exposes no Return to Campaign Map control; this campaign " +
        "is not free-roam and cannot produce the fixture prep-return needs",
    );
  }
  await clickSuffix(page, "/ReturnButton");
  await waitForScreen(page, "overworld-screen");
  const overworld = await bridge.snapshot(page);
  if (overworld.activeCampaign?.mapLive !== false) {
    throw new Error("campaign map reports a live map; this is not a between-map state");
  }
  await page.screenshot({ path: path.join(out, "06-prep-return-verified.png") });
  await writeFile(
    path.join(out, "06-prep-return-verified.json"),
    `${JSON.stringify({ prep: prep.activeCampaign, overworld: overworld.activeCampaign }, null, 2)}\n`,
  );
  return { prep: prep.activeCampaign, overworld: overworld.activeCampaign };
}


// user:// is IndexedDB on web and survives a reload of the same browser context, so
// reloading is how this reaches the main menu from the campaign map — the overworld
// toolbar has no route back, and a fresh context would start with an empty library.
async function reloadToMainMenu(page) {
  await page.reload({ waitUntil: "load" });
  await page.waitForFunction(
    (name) => Boolean(window[name]?.state),
    bridge.BRIDGE_GLOBAL,
    { timeout: TIMEOUT_MS },
  );
  await waitForScreen(page, "main-menu");
  await settle(page);
}

function campaignRowSlot(observed) {
  for (const controlPath of Object.keys(observed?.rects ?? {})) {
    const match = /\/Row_([^/]+)\/ExportButton$/.exec(controlPath);
    if (match) return match[1];
  }
  return null;
}

async function exportBetweenMapFixture(page, out) {
  await openLoadGame(page);
  const loaded = await bridge.snapshot(page);
  const slotId = campaignRowSlot(loaded);
  if (!slotId) throw new Error("the Prep save did not appear in Load Game with an Export control");

  const saveDestination = path.join(out, "free-roam-between-map-save.json");
  const saveDownloadReady = page.waitForEvent("download");
  await clickSuffix(page, `/Row_${slotId}/ExportButton`);
  const saveDownload = await saveDownloadReady;
  await saveDownload.saveAs(saveDestination);
  await page.keyboard.press("Enter");
  await settle(page);
  const saveBytes = await readFile(saveDestination);
  const save = JSON.parse(saveBytes.toString("utf8"));
  await page.screenshot({ path: path.join(out, "04-load-game-export.png") });

  // The backup is what the journey actually consumes, and it is exported by the real
  // Campaign Library surface so its pack component and its save come from the same
  // library rather than from a script assembling a ZIP.
  await clickSuffix(page, "/BtnBack");
  await waitForScreen(page, "campaign-library");
  await clickSuffix(page, "/BtnBack");
  await waitForScreen(page, "main-menu");
  await clickSuffix(page, "/CampaignLibraryButton");
  await waitForScreen(page, "campaign-library");
  const backupDestination = path.join(out, "free-roam-between-map-backup.zip");
  const backupDownloadReady = page.waitForEvent("download");
  await clickSuffix(page, "/BtnBackup", { settleAfter: false });
  const backupDownload = await backupDownloadReady;
  await backupDownload.saveAs(backupDestination);
  await settle(page);
  await page.keyboard.press("Enter");
  await settle(page);
  await page.screenshot({ path: path.join(out, "05-backup-exported.png") });

  const backupBytes = await readFile(backupDestination);
  return {
    slot_id: slotId,
    save: {
      path: saveDestination,
      bytes: saveBytes.length,
      sha256: createHash("sha256").update(saveBytes).digest("hex"),
      campaign: save.campaign,
      map_live: save.campaign?.map_live ?? null,
    },
    backup: {
      path: backupDestination,
      bytes: backupBytes.length,
      sha256: createHash("sha256").update(backupBytes).digest("hex"),
    },
  };
}


async function run(options) {
  await mkdir(options.out, { recursive: true });
  const server = await serve(options.webExport, options.port, options.contentScale, options.menuScale);
  let session;
  try {
    session = await boot({ url: server.url, viewport: options.viewport });
    assertClipAwareBridge(await bridge.snapshot(session.page));
    await session.page.screenshot({ path: path.join(options.out, "01-boot.png") });
    const importResult = await importPack(session.page, options.pack);
    await openNewGame(session.page);
    const entry = await selectCampaign(session.page, options.campaign);
    await clickSuffix(session.page, "/BtnStart");
    await waitForScreen(session.page, "prep");
    if (options.mode === "between-map") {
      await session.page.screenshot({ path: path.join(options.out, "01-prep.png") });
      await saveFromPrep(session.page, options.out);
      await reloadToMainMenu(session.page);
      const exported = await exportBetweenMapFixture(session.page, options.out);
      // Verified only after the backup is downloaded: loading a slot can consume it,
      // and a fixture that proved itself by destroying itself would be no fixture.
      await reloadToMainMenu(session.page);
      const verified = await assertFixtureReturnsToCampaignMap(
        session.page, exported.slot_id, options.out,
      );
      const betweenMap = {
        status: "passed", mode: options.mode, import: importResult, selected: entry,
        exported, prep_return_verified: verified,
      };
      await writeFile(
        path.join(options.out, "manual-free-roam-save.json"),
        `${JSON.stringify(betweenMap, null, 2)}\n`,
      );
      console.log(JSON.stringify(betweenMap, null, 2));
      return 0;
    }
    await clickSuffix(session.page, "/BeginButton");
    await session.page.waitForFunction(
      (name) => {
        try { return JSON.parse(window[name]?.state ?? "{}").activeCampaign?.mapLive === true; } catch { return false; }
      },
      bridge.BRIDGE_GLOBAL,
      { timeout: TIMEOUT_MS },
    );
    await settle(session.page);
    if (options.resizeAfterStart) { await session.page.setViewportSize(options.resizeAfterStart); await settle(session.page); }
    const live = await bridge.snapshot(session.page);
    if (live.map?.units?.length) {
      const unit = live.map.units[0];
      await session.page.mouse.click(unit.x, unit.y);
      await settle(session.page);
    }
    await session.page.screenshot({ path: path.join(options.out, "01-live-map.png") });
    const afterClick = await bridge.snapshot(session.page);
    await writeFile(path.join(options.out, "01-live-map.json"), `${JSON.stringify(afterClick, null, 2)}\n`);
    const capture = { status: "captured", import: importResult, selected: entry, live: afterClick.activeCampaign, map: afterClick.map, viewport: afterClick.viewport, scales: afterClick.scales };
    await writeFile(path.join(options.out, "live-map-capture.json"), `${JSON.stringify(capture, null, 2)}\n`);
    console.log(JSON.stringify(capture, null, 2));
    return 0;
    const exported = await saveAndExport(session.page, options.out);
    const result = {
      status: "passed", mode: options.mode, import: importResult, selected: entry,
      live: live.activeCampaign, exported,
    };
    await writeFile(path.join(options.out, "manual-free-roam-save.json"), `${JSON.stringify(result, null, 2)}\n`);
    console.log(JSON.stringify(result, null, 2));
    return 0;
  } finally {
    await teardown(session);
    await server.close();
  }
}

try {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) process.exit(usage());
  process.exit(await run(options));
} catch (error) {
  console.error(error.stack ?? error.message ?? error);
  process.exit(1);
}
