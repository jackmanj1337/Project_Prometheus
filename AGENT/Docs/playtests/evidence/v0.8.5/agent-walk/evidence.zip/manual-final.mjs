import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { boot, settle, teardown } from '../../../../tools/playwright/lib/harness.mjs';
import * as bridge from '../../../../tools/playwright/lib/bridge.mjs';
import { clickControl } from '../../../../tools/playwright/lib/clicks.mjs';

const out = path.resolve('builds/tester/Project_Prometheus_v0.8.5/agent-walk');
const pageOut = path.join(out, 'final-attempts');
await mkdir(pageOut, {recursive:true});
const session = await boot({url:'http://127.0.0.1:8765/?test_bridge=1&bridge_rects=all', viewport:{width:1280,height:720}});
const page = session.page;
let n=0;
async function snap(label) {
  await settle(page);
  const s=await bridge.snapshot(page);
  const prefix=String(++n).padStart(2,'0')+'-'+label;
  await page.screenshot({path:path.join(pageOut,prefix+'.png')});
  await writeFile(path.join(pageOut,prefix+'.json'), JSON.stringify(s,null,2));
  console.log(prefix, s?.screen, s?.modal, s?.activePackage);
  return s;
}
async function click(s, suffix) {
  const candidates=(s.controls||[]).filter(x=>x.endsWith(suffix));
  if(candidates.length!==1) throw new Error(`control ${suffix}: candidates ${JSON.stringify(candidates)}`);
  await clickControl(page,s,candidates[0]);
  return await snap('after-'+suffix.replaceAll('/','-'));
}
async function upload(s,suffix,file) {
 const chooser=page.waitForEvent('filechooser');
 const candidates=(s.controls||[]).filter(x=>x.endsWith(suffix));
 if(candidates.length!==1) throw new Error(`control ${suffix}: candidates ${JSON.stringify(candidates)}`);
 await clickControl(page,s,candidates[0],{settleAfter:false});
 await (await chooser).setFiles(path.resolve(file));
 return await snap('after-upload-'+path.basename(file));
}
try {
 let s=await snap('boot');
 console.log('INITIAL CONTROLS', (s.controls||[]).filter(x=>/Settings/.test(x)));
 if(s.controls?.some(x=>x.endsWith('/SettingsButton'))) s=await click(s,'/SettingsButton');
 s=await snap('settings-1280');
 console.log('SETTINGS CONTROLS', (s.controls||[]).filter(x=>/Scale|Back|Window/.test(x)));
 await page.setViewportSize({width:500,height:700});
 s=await snap('settings-500x700-1x');
 await page.mouse.move(480,500); await page.mouse.wheel(0,1100); await settle(page);
 s=await snap('settings-500x700-1x-scrolled');
 for (const [suffix,key] of [['/SliderUIScale','Home'],['/SliderViewportScale','Home']]) {
   const fresh=await bridge.snapshot(page); const match=(fresh.controls||[]).find(x=>x.endsWith(suffix));
   await clickControl(page,fresh,match); await page.keyboard.press(key); await settle(page);
 }
 s=await snap('settings-500x700-0_5x-app');
 for (const [suffix,key] of [['/SliderUIScale','End'],['/SliderViewportScale','End']]) {
   const fresh=await bridge.snapshot(page); const match=(fresh.controls||[]).find(x=>x.endsWith(suffix));
   await clickControl(page,fresh,match); await page.keyboard.press(key); await settle(page);
 }
 s=await snap('settings-500x700-2x-app');
} catch(e) { console.error('RUN_ERROR',e.stack); await snap('error-state').catch(()=>{}); }
await teardown(session);
