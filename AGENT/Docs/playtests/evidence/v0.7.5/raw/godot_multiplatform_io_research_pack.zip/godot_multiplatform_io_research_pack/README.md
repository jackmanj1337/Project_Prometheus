# Godot Multiplatform Filesystem & Text Entry Research Pack

**Focus:** Godot 4.x, especially Godot 4.7.1; native Windows exports; Web/PWA exports on Windows; Progressive Web Apps on iOS.

**Prepared:** 2026-08-11

## Contents

1. `01_research_report.md` — consolidated research report covering filesystem behavior, PWA persistence, external-file import/export, and multiplatform text entry.
2. `02_source_index.md` — annotated official guides, source code, open-source implementations, and deployed project examples.
3. `03_text_entry_implementation_patterns.md` — detailed comparison of four text-entry architectures, including the framing around focus, keyboard display, synchronization, and fallback behavior.
4. `04_test_checklist.md` — practical verification matrix for iOS PWA, Windows PWA, and native Windows.
5. `05_sample_architecture.md` — recommended project architecture and code-oriented notes for `SaveStore`, `ExternalFileIO`, and `TextEntryController`.
6. `06_reference_urls.csv` — machine-readable source list.

## Executive conclusion

Treat the project as **three runtime environments**, not two:

- Native Windows
- Web/PWA on Windows
- Web/PWA on iOS

A Windows PWA is still a Web export and therefore shares the browser sandbox, virtual filesystem, and browser text-entry constraints of the iOS PWA much more than it resembles a native Windows `.exe`.

For internal saves, use `user://` everywhere. On native Windows it maps to a real application-data directory; on Web it maps to a browser-backed virtual filesystem, typically persisted through IndexedDB.

For user-visible file import/export, hide platform differences behind an adapter:
- Native Windows: `FileDialog` + `FileAccess`
- Web/PWA: browser file picker / JavaScript bridge + `JavaScriptBridge.download_buffer()`

For text entry, start with Godot's normal `LineEdit`/`TextEdit`. On Web mobile, enable Godot's experimental virtual keyboard support and test it thoroughly on real iOS hardware. Keep a Godot-rendered onscreen keyboard available as a fallback if browser/native-keyboard integration proves unreliable in the actual deployment environment.

The strongest implementation references are:
- Godot's own `GodotDisplayVK` Web implementation
- `martinfuchs/Godot-Onscreen-Keyboard`
- `rzrabbi/rushy-bird-game`
- the historical `GodotWildJam17` / `window.prompt()` workaround
