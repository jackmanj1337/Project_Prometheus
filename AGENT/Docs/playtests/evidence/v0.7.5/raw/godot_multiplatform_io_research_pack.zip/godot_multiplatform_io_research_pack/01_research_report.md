# Consolidated Research Report

## 1. Target model

For this project, it is useful to distinguish three export/runtime combinations:

| Capability | Native Windows export | PWA/Web on Windows | PWA/Web on iOS |
|---|---|---|---|
| Packaged `res://` assets | Packaged/read-only | Packaged/read-only | Packaged/read-only |
| Writable `user://` | Real local app-data directory | Browser virtual filesystem | Browser virtual filesystem |
| Typical persistence backend | Windows filesystem | IndexedDB/browser storage | IndexedDB/WebKit storage |
| Arbitrary user file access | Native file dialog | Browser-mediated | Browser-mediated |
| Export arbitrary file | Normal save dialog | Browser download | Browser download/share behavior |
| Physical keyboard | Normal Godot input | Browser key events | External keyboard through browser |
| On-screen keyboard | Normally irrelevant | Web virtual keyboard on touch devices | Important and browser-dependent |
| Direct host filesystem access | Broad | Sandboxed | Sandboxed |

The key architectural point is:

> Installing a Web build as a PWA does not convert it into a native Windows or native iOS application. It remains a Web application running under the browser/WebView security and storage model.

---

# 2. Godot filesystem model

Godot deliberately uses portable path namespaces:

- `res://` — project resources and packaged content.
- `user://` — writable application data.

For exported games, code should generally treat `res://` as packaged/read-only and put mutable state under `user://`.

A portable save implementation can therefore remain unchanged across native Windows and Web:

```gdscript
const SAVE_PATH := "user://savegame.json"

func save_game(data: Dictionary) -> void:
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    file.store_string(JSON.stringify(data))

func load_game() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return {}

    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    return JSON.parse_string(file.get_as_text())
```

The important difference is what `user://` represents under each export target.

## Native Windows

By default, `user://` is stored under the user's application-data area. Godot documents the typical Windows location as:

```text
%APPDATA%\Godot\app_userdata\[project_name]
```

A custom user directory can change the final subdirectory naming.

This is a normal filesystem location even though application code should generally continue to use `user://`.

## Web/PWA

In a Web export, `user://` is a virtual filesystem. Browser security prevents Godot from treating arbitrary local folders as ordinary application paths. Godot stores its virtual filesystem using browser storage, with IndexedDB as the important persistence layer.

Conceptually:

```text
Browser / installed PWA
└── private origin storage
    └── Godot virtual filesystem
        └── user://
            ├── settings.cfg
            └── savegame.json
```

The files are not equivalent to user-visible files in Windows Explorer or the iOS Files application.

---

# 3. PWA caching and save storage are different systems

A Godot PWA uses a service worker and browser cache mechanisms so the application itself can launch offline.

That should be kept conceptually separate from player data:

```text
Service worker / cache
    -> game executable/assets/offline availability

IndexedDB / user://
    -> saves/settings/generated application data
```

This distinction matters when debugging "offline works but my save disappeared" or the reverse.

Browser storage can be subject to quota, eviction, private-browsing behavior, origin changes, and platform-specific persistence rules. Godot exposes `OS.is_userfs_persistent()` to give applications a way to inspect whether `user://` appears persistent, but browser persistence should still be treated as less absolute than a native filesystem.

For valuable campaign data, an explicit export/import mechanism is a useful secondary safety path even if cloud saves are eventually added.

---

# 4. Important iOS PWA storage behavior

WebKit has documented a separation between ordinary Safari website data and a Home Screen web application's data context. In particular, installing a site to the Home Screen should not be assumed to migrate all existing local browser storage into the newly installed web app.

A risky user flow is therefore:

```text
1. Open game in Safari.
2. Play for a substantial period.
3. Save into Safari's IndexedDB.
4. Add the game to the Home Screen.
5. Launch the installed PWA.
6. Expect the Safari save automatically to exist there.
```

Do not design around that expectation without testing the exact iOS release being supported.

Practical responses:

1. Encourage installation before substantial play.
2. Provide Export Save / Import Save.
3. Add account-based/cloud synchronization if campaign data becomes valuable enough.
4. Test upgrades, reinstall, storage pressure, and clearing browser data explicitly.

---

# 5. Importing arbitrary user files

## Native Windows

Godot can use `FileDialog` / native file dialogs to let the player choose a file. Once a path is returned, ordinary `FileAccess` and runtime loaders can read the file.

This is appropriate for features such as:

- import map
- load mod package
- select custom image
- import save
- choose replay
- select user-authored scenario

## Web/PWA

Godot's ordinary filesystem dialog cannot simply browse the host filesystem in a Web export. Browser security requires a user-mediated file selection.

The conventional Web architecture is:

```text
Godot UI
   ↓
browser <input type="file"> or file-picker API
   ↓
JavaScript File / ArrayBuffer
   ↓
PackedByteArray / String passed to Godot
   ↓
game importer parses contents
```

The important design recommendation is to make game import logic operate on **bytes or text**, not paths.

Good:

```gdscript
func import_map(contents: PackedByteArray) -> void:
    # Parse the bytes independent of where they came from.
    pass
```

Less portable:

```gdscript
func import_map(path: String) -> void:
    # Forces the rest of the game to care how each platform obtained a path.
    pass
```

A useful community implementation is the HTML5 File Dialogs addon, which wraps browser file selection and returns user-selected file contents to Godot.

---

# 6. Exporting files from Web

Godot exposes:

```gdscript
JavaScriptBridge.download_buffer(
    data,
    "campaign-save.json",
    "application/json"
)
```

This asks the browser to save/download the supplied bytes.

It should normally happen directly from a user action such as an Export button because browsers may block unsolicited downloads.

A portable abstraction can therefore expose one action to the game:

```text
export_file(data, suggested_name, mime_type)
```

with different backends:

```text
Native Windows:
    save dialog
    -> FileAccess

Web/PWA:
    JavaScriptBridge.download_buffer()
    -> browser download/save UI
```

---

# 7. Text entry: the normal Godot layer

For ordinary game UI, the portable control layer is still:

- `LineEdit` for single-line text
- `TextEdit` for multiline text

This is the correct starting point for:

- character names
- save names
- search
- chat
- email
- password
- small notes

Native Windows simply uses normal keyboard input.

Desktop Web normally receives browser keyboard events while the Godot canvas is focused.

Mobile Web is different because browsers generally show their software keyboard only when an actual editable HTML element is focused.

---

# 8. Godot's Web virtual keyboard architecture

Godot solves the browser constraint by creating real DOM editing controls and bridging them back to Godot.

The current Web implementation contains a virtual-keyboard helper commonly referred to through the `GodotDisplayVK` implementation.

The flow is approximately:

```text
Player taps Godot LineEdit/TextEdit
        ↓
Godot control gains editing focus
        ↓
DisplayServer requests virtual keyboard
        ↓
Web backend activates a hidden/managed DOM element
        ↓
<input> for single-line entry
<textarea> for multiline entry
        ↓
browser focuses DOM element
        ↓
iOS/Android browser shows native keyboard
        ↓
DOM "input" event fires as text changes
        ↓
value + selection/caret state passed to Godot
        ↓
LineEdit/TextEdit updated
```

The engine maps semantic Godot keyboard modes to browser input semantics, including numeric, decimal, phone, email, password, URL, and multiline forms.

This matters because the iOS keyboard can then choose an appropriate key layout and use native facilities such as autocorrection or IME behavior.

Godot still labels the Web export option `html/experimental_virtual_keyboard` as experimental in current stable documentation.

---

# 9. Why the implementation is structured this way

Godot's Web progress report explains the underlying browser limitation well:

- Web pages cannot freely summon the mobile keyboard for a canvas.
- Browsers expect an actual `<input>` or `<textarea>` to receive editing focus.
- IME, autocorrect, composition, and browser text handling are more complex than individual key-down events.
- Therefore Godot reads/synchronizes the state of a real editable browser element.

This is appropriate for short text such as:

- leaderboard nickname
- player name
- email
- short chat message

It deserves more testing for large, editor-like multiline text.

---

# 10. Complete open-source alternative: Godot-Onscreen-Keyboard

`martinfuchs/Godot-Onscreen-Keyboard` is an MIT-licensed Godot 4 plugin that renders the keyboard entirely inside the Godot scene.

Typical usage:

1. Install the addon.
2. Enable the plugin.
3. Add an `OnscreenKeyboard` node.
4. Focus a `LineEdit` or `TextEdit`.
5. The keyboard displays automatically.
6. Key buttons generate Godot input events.

A particularly clean part of the implementation is that it does not have to mutate strings manually for every normal key. It builds `InputEventKey` events and feeds them through Godot's input system using `Input.parse_input_event()`.

Architecture:

```text
Godot keyboard button
        ↓
InputEventKey
        ↓
Input.parse_input_event()
        ↓
normal Godot input handling
        ↓
currently focused LineEdit/TextEdit
```

The addon also handles surrounding interaction:

- detecting focused text controls
- showing/hiding the keyboard
- Enter behavior
- keyboard animation
- multiple keyboard layouts
- shift/special keys
- customization through Godot resources/JSON

## Tradeoff

The user is interacting with a game-rendered keyboard rather than the native iOS keyboard.

Advantages:
- highly predictable across platforms
- completely controlled by the game
- works around browser/iframe keyboard failures
- consistent appearance
- can be gamepad/touch optimized

Disadvantages:
- no native iOS keyboard UI
- weaker autocorrect/prediction
- less complete language/IME behavior
- dictation/password-manager integration is not inherited automatically
- accessibility behavior must be considered separately

It is a strong choice for short game-oriented fields such as unit names and save names, and a useful fallback even when the native keyboard is the preferred path.

---

# 11. Production-style example: Rushy Bird

The open-source `rzrabbi/rushy-bird-game` project is valuable because it documents the surrounding deployment problem, not merely a keyboard widget.

The game has multiple real text-entry requirements, including name/account fields. Its Web build may be hosted inside cross-origin iframes such as itch.io, where mobile browser restrictions can make native virtual-keyboard behavior unreliable.

The project therefore customized an onscreen keyboard and made keyboard selection platform-aware.

Its documented strategy is roughly:

```text
                   text field
                       ↓
              determine environment
                       ↓
       ┌───────────────┼────────────────┐
       ↓               ↓                ↓
native mobile      mobile Web        desktop
Android/iOS        / iframe          native/Web
       ↓               ↓                ↓
native OS          custom Godot      physical
keyboard           onscreen          keyboard
                   keyboard
```

Important surrounding behaviors include:

- mobile Web detection
- avoiding duplicate native + custom keyboard activation
- changing focus/virtual-keyboard behavior on affected fields
- platform-specific defaults
- active-field indication
- field switching
- caret/text handling where needed

This is a useful example of treating keyboard strategy as an **environment capability decision** rather than embedding Web-specific logic in every form.

The project is Godot 3.x-era code, so copy the architecture rather than the APIs verbatim.

---

# 12. Historical browser-owned editing example: window.prompt()

Before Godot's built-in Web virtual keyboard matured, projects used the browser's `window.prompt()` as a simple way to hand text editing to the browser.

The conceptual flow:

```text
tap/click Godot field
        ↓
JavaScript window.prompt()
        ↓
browser owns text entry
        ↓
user presses OK
        ↓
returned String assigned to Godot LineEdit
```

This pattern is crude but useful because it demonstrates a clean ownership boundary:

> While the user is editing, the browser is the text editor. Godot receives the completed value.

That same ownership model can be used in a much better modern custom DOM overlay.

---

# 13. Custom DOM input overlay

A more advanced implementation can use Godot's custom HTML shell / head include together with `JavaScriptBridge`.

The project can create its own `<input>` or `<textarea>` element and communicate with it explicitly.

Example flow:

```text
Godot displays game-styled field
        ↓
player activates field
        ↓
TextEntryController requests browser editing
        ↓
JavaScript creates/shows real <input>
        ↓
browser/iOS owns keyboard + IME
        ↓
input/change events
        ↓
JavaScript callback into GDScript
        ↓
Godot field/state updated
        ↓
Done/blur closes DOM editor
```

This gives the project more control than Godot's built-in experimental bridge while retaining the native iOS keyboard.

It also means the project owns:
- DOM positioning
- focus transitions
- zoom/viewport handling
- keyboard open/close behavior
- CSS
- text selection
- synchronization
- accessibility semantics
- browser compatibility

For that reason, it is best treated as a third-stage solution after testing the built-in bridge and a Godot-only fallback.

---

# 14. Recommended text-entry strategy

For a game targeting native Windows + Windows PWA + iOS PWA:

## Primary

Use normal Godot `LineEdit` / `TextEdit`.

## Mobile Web

Enable `html/experimental_virtual_keyboard`.

Test on real iOS hardware early.

## Fallback

Keep a Godot-rendered onscreen keyboard behind a `TextEntryController` abstraction.

## Escalation

Only build a custom DOM editor if:
- the built-in bridge has a reproducible blocking problem, and
- the Godot-only keyboard lacks required native text features.

This avoids taking ownership of browser editing complexity prematurely.

---

# 15. Recommended project boundaries

Three small services keep most code platform-independent:

```text
SaveStore
    internal persistent application data

ExternalFileIO
    user-visible imports/exports

TextEntryController
    selection of text-entry strategy
```

Conceptual map:

```text
                         GAME CODE
                            │
       ┌────────────────────┼────────────────────┐
       │                    │                    │
   SaveStore          ExternalFileIO      TextEntryController
       │                    │                    │
 FileAccess            platform adapter       LineEdit/
 user://                    │                 TextEdit
       │             ┌──────┴──────┐        ┌────┴───────────┐
       │             │             │        │                │
   Windows/Web     Windows        Web      normal        fallback
       │          FileDialog   JS picker   Web VK        Godot OSK
       │          FileAccess   download
       │
 ┌─────┴───────┐
 Windows       Web
 AppData     IndexedDB
```

The rest of the game should preferably not ask:
- "Am I on iOS?"
- "Am I in JavaScript?"
- "What path did the player select?"
- "Should I show the HTML keyboard?"

Instead it should request semantic operations such as:
- save campaign
- import map bytes
- export save
- edit character name

The adapter layer then chooses the correct platform mechanism.

---

# 16. What should be prototyped first

The highest-value prototype is a small Web/PWA test scene containing:

- short `LineEdit`
- password `LineEdit`
- email `LineEdit`
- numeric `LineEdit`
- multiline `TextEdit`
- two fields next to each other
- fields near top and bottom of screen
- export save
- import save
- automatic save to `user://`

Test that scene on:

1. Native Windows
2. Chromium Windows browser
3. Installed Windows PWA
4. iPhone Safari
5. Installed iPhone Home Screen PWA
6. iPad if it is a target
7. External keyboard on iOS if expected

Do this before building forms deeply into the game.
