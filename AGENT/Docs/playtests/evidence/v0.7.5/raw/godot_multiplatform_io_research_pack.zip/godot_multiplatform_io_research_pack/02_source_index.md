# Annotated Source & Example Index

**Retrieved / checked:** 2026-08-11

The list is ordered approximately by practical value.

---

## Official Godot sources

### Godot 4.7.1 release

**URL:** https://github.com/godotengine/godot/releases/tag/4.7.1-stable

Why it matters:
- Confirms the current stable maintenance release used as the reference point for this pack.

---

### File paths in Godot projects

**URL:** https://docs.godotengine.org/en/stable/tutorials/io/data_paths.html

Why it matters:
- Canonical description of `res://` and `user://`.
- Documents platform-specific user-data locations.
- Essential starting point for portable save architecture.

---

### Filesystem tutorial

**URL:** https://docs.godotengine.org/en/stable/tutorials/scripting/filesystem.html

Why it matters:
- General Godot filesystem concepts and runtime file operations.

---

### Runtime file loading and saving

**URL:** https://docs.godotengine.org/en/stable/tutorials/io/runtime_file_loading_and_saving.html

Why it matters:
- Covers user-provided/runtime-loaded files rather than only imported project resources.

---

### FileDialog class

**URL:** https://docs.godotengine.org/en/stable/classes/class_filedialog.html

Why it matters:
- Native file-dialog behavior and access modes.
- Important limitation: Web exports do not get ordinary unrestricted host-filesystem browsing.

---

### DisplayServer class

**URL:** https://docs.godotengine.org/en/stable/classes/class_displayserver.html

Why it matters:
- Native display/input/platform services, including platform file-dialog and virtual-keyboard APIs.

---

### Exporting for the Web

**URL:** https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_web.html

Why it matters:
- Primary guide for current Godot Web exports.
- PWA configuration.
- Browser constraints.
- Persistence considerations.
- Web deployment behavior.

---

### EditorExportPlatformWeb

**URL:** https://docs.godotengine.org/en/stable/classes/class_editorexportplatformweb.html

Why it matters:
- Documents Web export properties.
- Includes `html/experimental_virtual_keyboard`.
- Includes PWA and custom HTML-shell properties.

Key current detail:
- The virtual keyboard feature is still explicitly labeled experimental.

---

### JavaScriptBridge

**URL:** https://docs.godotengine.org/en/stable/tutorials/platform/web/javascript_bridge.html

Class:
https://docs.godotengine.org/en/stable/classes/class_javascriptbridge.html

Why it matters:
- Primary supported bridge between GDScript and browser JavaScript.
- Foundation for custom DOM inputs, browser APIs, file downloads, callbacks, and advanced Web integration.
- `download_buffer()` is particularly useful for save/map export.

---

### OS class

**URL:** https://docs.godotengine.org/en/stable/classes/class_os.html

Why it matters:
- Feature/environment detection.
- `OS.has_feature(...)`.
- Persistence-related checks such as `OS.is_userfs_persistent()`.

---

## Godot engine source / design rationale

### Web Progress Report #7: Virtual keyboard on the Web

**URL:** https://godotengine.org/article/godot-web-progress-report-7/

Why it matters:
- Best explanation of the browser problem that motivated the implementation.
- Explains why the Web backend uses real HTML `<input>` / `<textarea>` elements.
- Discusses IME/autocomplete and why short text is a better target than editor-scale text.
- Historical article, but the architecture remains directly relevant.

---

### Current Godot Web virtual-keyboard source

**URL:**  
https://github.com/godotengine/godot/blob/4.7.1-stable/platform/web/js/libs/library_godot_display.js

What to inspect:
- `GodotDisplayVK`
- creation of `input` / `textarea`
- DOM `input` event handling
- focus/show/hide path
- keyboard/input-type mapping
- selection/caret synchronization

Why it matters:
- This is effectively a complete implementation example of the hidden-DOM-input architecture.

---

## Official Godot demo projects

### Serialization / saving demo

**URL:** https://github.com/godotengine/godot-demo-projects/tree/master/loading/serialization

Why it matters:
- Concrete `FileAccess`, JSON, and configuration serialization examples.
- Useful baseline for `user://` save handling.

---

### Control Gallery

**URL:** https://github.com/godotengine/godot-demo-projects/tree/master/gui/control_gallery

Why it matters:
- Reference for standard Godot UI controls, including text controls and normal focus behavior.

---

## Open-source text-entry implementations

### martinfuchs / Godot-Onscreen-Keyboard

**Repository:** https://github.com/martinfuchs/Godot-Onscreen-Keyboard

**Asset Library:** https://godotengine.org/asset-library/asset/1328

License:
- MIT

Godot:
- Godot 4.x plugin; Asset Library entry lists 4.1 support for version 2.0.

Why it matters:
- Most useful complete Godot-only keyboard implementation found.
- Automatically reacts to `LineEdit` / `TextEdit` focus.
- Generates `InputEventKey` input rather than tightly coupling every key to string mutation.
- Supports layouts, shift/special keys, styling, show/hide behavior.

Best use:
- Game-oriented short text.
- Touchscreen kiosk-like UI.
- Fallback when mobile-browser native keyboard behavior is unreliable.

---

### rzrabbi / rushy-bird-game

**Repository:** https://github.com/rzrabbi/rushy-bird-game

Indexed mirror/documentation:
https://git.hubp.de/rzrabbi/rushy-bird-game

Why it matters:
- Real game with login/name text requirements.
- Documents mobile-Web / iframe keyboard problems.
- Uses a customized Godot onscreen keyboard.
- Routes between native mobile keyboard, custom mobile-Web keyboard, and desktop behavior.
- Includes the surrounding framing: environment detection, field handling, platform rules, and user-facing behavior.

Caution:
- Godot 3.x-era project/API patterns; use the architecture, not copy-paste assumptions.

---

### NimbleBeasts / GodotWildJam17

**Repository:** https://github.com/NimbleBeasts/GodotWildJam17

Related forum discussion:
https://forum.godotengine.org/t/virtual-keyboard-workaround-in-html5/20335

Why it matters:
- Historical implementation showing browser-owned editing through `window.prompt()`.
- Very simple demonstration of handing text entry to browser UI and returning the final string to Godot.

Best use:
- Architectural reference for "browser owns the edit session".
- Not recommended as modern production UI.

---

## Examples of projects using Godot-Onscreen-Keyboard

### Surreal Lifestyle

**Project page:** https://astecarmyman.itch.io/surreal-lifestyle

Why it matters:
- Publicly credits `Godot-Onscreen-Keyboard` among its plugins.
- Shows the addon being used in a real shipped/jam-style project.

---

### Price calculator for Upgrade balance

**Project page:** https://coscom.itch.io/calculatorpriceupgrade

Why it matters:
- HTML5 tool explicitly notes use of the Godot onscreen-keyboard project.
- Useful as another deployed Web example.

---

## Web file-access implementations

### HTML5 File Dialogs

Search/reference:
- Godot Asset Library / community package generally known as "HTML5 File Dialogs".

Why it matters:
- Demonstrates browser `<input type="file">` integration.
- Useful model for receiving selected files as text or byte arrays rather than depending on host paths.

Suggested lookup:
https://godotengine.org/asset-library/

Search for:
`HTML5 File Dialogs`

---

## WebKit / iOS storage references

### WebKit storage policy

**URL:** https://webkit.org/blog/14403/updates-to-storage-policy/

Why it matters:
- Browser storage quotas and persistence behavior on Apple platforms.
- Important background for long-lived `user://` data in a Web/PWA build.

---

### WebKit Home Screen web-app behavior

**URL:** https://webkit.org/blog/14787/webkit-features-in-safari-17-2/

Why it matters:
- Describes Home Screen web-app behavior and separation from ordinary Safari website state.
- Relevant when deciding whether pre-install Safari saves can be assumed to appear in the installed PWA.

---

### Origin Private File System on WebKit

**URL:** https://webkit.org/blog/12257/the-file-system-access-api-with-origin-private-file-system/

Why it matters:
- Shows the distinction between private origin-managed storage and user-visible host filesystem access.
- Useful if large/high-frequency browser file storage becomes necessary later.

---

## Useful forum evidence / issue context

### How do you bring up the keyboard on mobile in HTML5?

**URL:** https://forum.godotengine.org/t/how-do-you-bring-up-the-keyboard-on-mobile-in-html5/17603

Why it matters:
- Historical context showing how long mobile-browser keyboard behavior has been a practical concern.

---

### Virtual Keyboard Workaround in HTML5?

**URL:** https://forum.godotengine.org/t/virtual-keyboard-workaround-in-html5/20335

Why it matters:
- Contains the `window.prompt()` workaround.
- Later comments show that mobile-browser differences can still matter even after engine support exists.
- Forum reports are anecdotal rather than authoritative, but useful for choosing test cases.
