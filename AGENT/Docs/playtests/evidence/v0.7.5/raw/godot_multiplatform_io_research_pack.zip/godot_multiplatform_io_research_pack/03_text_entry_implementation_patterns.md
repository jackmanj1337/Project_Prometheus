# Text Entry Implementation Patterns

This document focuses on the **framing around the keyboard**, not only the API call that produces characters.

A complete text-entry implementation needs to answer:

1. What tells the system that editing has started?
2. Which component owns the edit session?
3. How is the keyboard opened?
4. Where does the authoritative string live while editing?
5. How are caret/selection/IME changes handled?
6. How does the user finish/cancel?
7. How is focus transferred between fields?
8. What happens when the viewport changes because a mobile keyboard opens?
9. What fallback is used when a browser cannot reliably invoke the native keyboard?
10. Which behavior changes by target?

---

# Pattern A — Normal Godot text control + built-in Web virtual keyboard

## Best default for this project

Use:
- `LineEdit`
- `TextEdit`
- Web export option `html/experimental_virtual_keyboard`

## Ownership

Godot owns the visible game UI and logical text control.

On mobile Web, the Godot Web backend temporarily relies on a real browser `<input>` or `<textarea>` so the browser can own the low-level text-composition interaction.

## Flow

```text
tap LineEdit
    ↓
Godot GUI focus
    ↓
DisplayServer virtual-keyboard request
    ↓
Godot Web JS selects/creates DOM editor
    ↓
DOM editor receives existing text/selection
    ↓
browser focuses it
    ↓
iOS shows native keyboard
    ↓
DOM input/composition updates
    ↓
Godot Web bridge forwards text + caret state
    ↓
LineEdit/TextEdit updates
    ↓
editing ends / focus changes
    ↓
DOM editor hidden
```

## Framing requirements

The game should still implement:
- clear focus styling
- explicit Done/OK behavior where appropriate
- safe traversal to next field
- screen layout that remains usable when iOS resizes or obscures part of the viewport
- validation after text changes or on submission
- cancellation semantics if required

## Advantages

- Least custom code
- Preserves Godot controls
- Gets native iOS keyboard
- Browser can provide autocorrect/IME/input-mode behavior
- Desktop path remains normal

## Risks

- Export setting remains experimental
- mobile browsers differ
- iframe embedding can alter behavior
- large multiline editing deserves specific testing
- focus/viewport behavior is likely to be more fragile than normal desktop input

## Reference implementation

Godot engine:
`platform/web/js/libs/library_godot_display.js`

---

# Pattern B — Game-rendered onscreen keyboard

## Best fallback for unreliable mobile Web environments

Use:
- normal Godot `LineEdit` / `TextEdit` or a custom field
- `Godot-Onscreen-Keyboard` style input layer

## Ownership

Godot owns:
- visible field
- keyboard
- touch buttons
- key events
- layout
- focus

The browser does not need to show the OS keyboard.

## Flow

```text
tap LineEdit
    ↓
field gets GUI focus
    ↓
OnscreenKeyboard observes focused control
    ↓
keyboard animates into game UI
    ↓
tap "A"
    ↓
plugin creates InputEventKey
    ↓
Input.parse_input_event()
    ↓
focused LineEdit handles normal key input
    ↓
Done/Enter or focus loss
    ↓
keyboard hides
```

## Why generated InputEventKey is useful

It keeps text behavior closer to normal Godot editing:

```text
custom key button
      ↓
Godot input event
      ↓
normal focused control
```

instead of every field implementing:

```text
if key == BACKSPACE:
    manually rewrite string
elif key == LEFT:
    manually update caret
...
```

Some special behavior may still require custom handling, but the event-driven architecture is cleaner.

## Framing requirements

A complete onscreen keyboard should handle:
- which field is active
- focus indicator
- hide/show animation
- keyboard safe area
- Enter / Done
- Backspace
- caret movement
- shift/caps
- symbols/numbers
- field switching
- maximum length
- allowed-character filtering
- gamepad focus, if relevant
- avoiding clicks on the keyboard causing accidental field focus loss

## Advantages

- consistent browser behavior
- works in restrictive iframe scenarios
- visually matches game
- deterministic layout
- can be gamepad-friendly

## Costs

- no native autocorrect/prediction
- IME/language support becomes your problem
- accessibility becomes more work
- passwords/email/native keyboard conveniences are weaker
- occupies game-screen space

## Complete example

`martinfuchs/Godot-Onscreen-Keyboard`

## Production framing example

`rzrabbi/rushy-bird-game`

---

# Pattern C — Browser-owned modal edit session

Historical simplest form:
`window.prompt()`

Modern form:
custom DOM modal/overlay.

## Ownership

The game starts the edit operation, then the browser owns text editing until completion.

## Flow

```text
player activates field
      ↓
game calls begin_browser_edit(initial_text)
      ↓
DOM editor/modal opens
      ↓
native iOS keyboard opens
      ↓
browser handles text/selection/IME
      ↓
user presses Done or Cancel
      ↓
callback returns final string or cancellation
      ↓
Godot updates game state
```

## Important framing choice

Unlike Pattern A, you do **not** necessarily synchronize every keystroke to the visible Godot field.

The browser can be authoritative for the duration of the edit session.

That considerably reduces synchronization complexity.

## Good use cases

- character naming screen
- save-file naming
- account forms
- fields edited infrequently
- text entry where a temporary overlay is acceptable

## Less suitable

- chat that needs live rendering in the game
- rich editing
- fields that must remain visually embedded in rapidly changing gameplay UI

## Historical example

GodotWildJam17 / forum `window.prompt()` workaround.

---

# Pattern D — Custom DOM field synchronized with Godot

## Highest control, highest implementation cost

This is the most direct custom-Web architecture.

## Ownership

Godot owns the game's logical field and styling.

A real browser `<input>` / `<textarea>` owns low-level mobile editing.

The project, rather than Godot's engine Web backend, owns the synchronization bridge.

## Components

```text
Godot
├── TextEntryController.gd
├── LineEdit/TextEdit or custom display control
└── JavaScriptBridge callback

HTML/JavaScript
├── <input>
├── <textarea>
├── CSS
├── focus/blur handlers
├── input/composition handlers
└── callback into Godot
```

## Possible synchronization modes

### Live synchronization

```text
DOM input
  ↓ every change
Godot string
```

Pros:
- game always shows current text

Cons:
- composition/IME/caret synchronization is harder

### Commit synchronization

```text
DOM input
  ↓ only Done/blur
final string
  ↓
Godot
```

Pros:
- much simpler
- browser fully owns edit session

Cons:
- less live integration

### Hybrid

Synchronize the text live but only treat selection/caret as authoritative in DOM until Done.

## Main implementation concerns

- obtaining the active field rectangle
- translating Godot canvas coordinates to CSS pixels
- device-pixel ratio
- browser zoom
- iOS visual viewport
- orientation changes
- keyboard-induced viewport changes
- focus restrictions requiring a real user gesture
- composition events
- text selection
- scroll-to-field behavior
- accessibility
- hiding without accidentally reopening
- PWA standalone mode
- iframe restrictions

## Recommendation

Do not make this the first implementation. It becomes attractive only when a reproducible requirement is not met by the built-in Godot bridge or the Godot-only keyboard.

---

# Environment-routing pattern

A production system should let environment/capability selection happen in one place.

Example:

```text
TextEntryController
    │
    ├── Native Windows
    │      -> normal LineEdit
    │
    ├── Windows Web/PWA
    │      -> normal LineEdit
    │         + built-in VK only on touch if needed
    │
    ├── iOS PWA
    │      -> built-in Web VK by default
    │
    └── known-problem Web/iframe environment
           -> custom Godot onscreen keyboard
```

This pattern is visible conceptually in Rushy Bird.

---

# Recommended field model

A useful abstraction is to describe **what kind of text the game wants**, not which platform API to call.

```gdscript
class_name TextEntryRequest

enum Kind {
    NAME,
    EMAIL,
    PASSWORD,
    INTEGER,
    DECIMAL,
    URL,
    CHAT,
    MULTILINE_NOTE,
}

var kind: Kind
var initial_text := ""
var placeholder := ""
var max_length := 0
var multiline := false
var allow_cancel := true
```

Then:

```gdscript
TextEntryController.begin_edit(field, request)
```

The controller decides how that request is implemented on the current runtime.

---

# Recommended decision order

1. Standard Godot `LineEdit` / `TextEdit`
2. Built-in Web experimental virtual keyboard
3. Godot-only onscreen keyboard fallback
4. Custom DOM implementation for a demonstrated requirement

That order keeps complexity proportional to actual observed problems.
