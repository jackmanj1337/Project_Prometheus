# Multiplatform Verification Checklist

This checklist is intended for a small dedicated test scene before the game's production UI depends heavily on text entry or browser storage.

---

# Test environments

Run the same build/features on:

- [ ] Native Windows export
- [ ] Windows Chromium-family browser
- [ ] Installed Windows PWA
- [ ] iPhone Safari
- [ ] Installed iPhone Home Screen PWA
- [ ] iPad Safari / PWA if supported
- [ ] iOS external Bluetooth/hardware keyboard if expected
- [ ] Target embedded host/iframe, if the game will run on itch.io or another framed site

Record:
- device
- OS version
- browser version
- Godot version
- export preset/hash
- PWA installed vs browser tab
- iframe vs top-level page

---

# Basic LineEdit

- [ ] Tap field and obtain focus
- [ ] Native iOS keyboard opens
- [ ] First typed character appears
- [ ] Continuous typing works
- [ ] Backspace works
- [ ] Delete selection works
- [ ] Move caret left/right
- [ ] Tap to reposition caret
- [ ] Select text
- [ ] Replace selected text
- [ ] Copy
- [ ] Paste
- [ ] Cut
- [ ] Undo/redo if expected
- [ ] Max length enforced
- [ ] Allowed-character filtering works
- [ ] Placeholder disappears/reappears correctly
- [ ] Clear button if used

---

# IME / composition / language

At minimum test representative non-simple input if the game may be internationalized.

- [ ] accented Latin input
- [ ] emoji
- [ ] smart punctuation
- [ ] CJK IME if practical
- [ ] composition does not duplicate text
- [ ] caret position remains sensible after composition
- [ ] autocorrect replacement does not duplicate/delete neighboring text

---

# Keyboard-type semantics

Create separate fields for:

- [ ] normal text
- [ ] email
- [ ] password
- [ ] integer
- [ ] decimal
- [ ] phone
- [ ] URL
- [ ] multiline

Verify the expected iOS keyboard/layout appears where relevant.

---

# Password field

- [ ] keyboard opens
- [ ] characters are masked correctly in Godot UI
- [ ] editing selection does not expose unexpected plaintext
- [ ] paste behavior is acceptable
- [ ] password manager behavior is understood
- [ ] submission does not log plaintext accidentally

---

# Multiline TextEdit

- [ ] keyboard opens
- [ ] Return inserts newline rather than unexpectedly submitting
- [ ] several paragraphs can be entered
- [ ] scrolling remains usable
- [ ] caret remains visible
- [ ] selection across lines works
- [ ] performance remains acceptable
- [ ] orientation change does not corrupt content

If multiline text is only a minor feature, define an explicit maximum size and test at that maximum.

---

# Field switching

Create two or more neighboring fields.

- [ ] tap field A
- [ ] keyboard opens
- [ ] type
- [ ] tap field B
- [ ] active field switches correctly
- [ ] keyboard remains usable
- [ ] no text goes to old field
- [ ] Done/Next semantics are sensible
- [ ] keyboard does not flash closed/open unnecessarily
- [ ] focus indicator follows correct field

---

# Keyboard dismissal

- [ ] tap outside field
- [ ] press Done
- [ ] press Return where submission is intended
- [ ] switch scene
- [ ] open pause menu
- [ ] background the PWA
- [ ] return to PWA
- [ ] rotate device
- [ ] no invisible focused DOM field continues capturing input

---

# Layout / viewport

Place test fields:
- at top
- center
- near bottom
- inside ScrollContainer
- inside popup/modal

Verify:

- [ ] active field remains visible above keyboard
- [ ] UI does not become permanently offset
- [ ] safe-area insets are respected
- [ ] portrait
- [ ] landscape
- [ ] rotate while keyboard is open
- [ ] browser address-bar expansion/collapse does not break layout
- [ ] installed PWA standalone mode
- [ ] viewport recovers after keyboard closes

---

# Godot-only onscreen keyboard fallback

If using `Godot-Onscreen-Keyboard` or similar:

- [ ] automatically opens for intended fields
- [ ] does not open for fields that should use native keyboard
- [ ] closes on Done
- [ ] closes on focus loss
- [ ] does not steal focus unexpectedly
- [ ] Backspace
- [ ] Shift
- [ ] Caps
- [ ] symbols
- [ ] number layout
- [ ] field switching
- [ ] cursor movement
- [ ] max length
- [ ] disabled/read-only fields
- [ ] gamepad navigation if relevant
- [ ] screen remains usable with keyboard occupying lower area
- [ ] keyboard state resets across scene changes

---

# `user://` persistence

Create a test save containing:
- random UUID
- timestamp
- counter
- several KB of JSON
- optionally a larger binary payload

Test:

- [ ] save
- [ ] close/reopen game
- [ ] browser reload
- [ ] hard reload
- [ ] close browser
- [ ] restart device
- [ ] PWA background/resume
- [ ] PWA force-close/relaunch
- [ ] app update / new Web deployment
- [ ] offline launch
- [ ] regain network
- [ ] inspect `OS.is_userfs_persistent()`
- [ ] confirm behavior in private browsing is documented

---

# Safari → installed PWA transition

This deserves an explicit test rather than an assumption.

- [ ] open game in Safari
- [ ] create save A
- [ ] verify save A in Safari
- [ ] Add to Home Screen
- [ ] launch installed PWA
- [ ] record whether save A is visible
- [ ] create save B in installed PWA
- [ ] return to Safari
- [ ] record whether save B is visible
- [ ] document expected user behavior based on observed result

---

# Save export

- [ ] Export button is directly user initiated
- [ ] filename is sensible
- [ ] MIME type sensible
- [ ] downloaded file contains correct data
- [ ] native Windows uses save dialog as expected
- [ ] Windows PWA download works
- [ ] iOS Safari download works
- [ ] installed iOS PWA download behavior is acceptable
- [ ] exported save can be imported again

---

# Save/file import

- [ ] browser picker opens only from user action
- [ ] accepted file types filter correctly
- [ ] select valid file
- [ ] cancel picker
- [ ] select invalid file
- [ ] select corrupt file
- [ ] large file
- [ ] duplicate import
- [ ] error does not destroy existing save
- [ ] import logic receives bytes/text independently of platform path

---

# PWA offline/update behavior

- [ ] first online load
- [ ] install PWA
- [ ] launch offline
- [ ] existing save present
- [ ] deploy new version
- [ ] update cached application
- [ ] old save remains readable
- [ ] migration runs if save schema changed
- [ ] interrupted update does not destroy save
- [ ] service-worker cache failure is distinguishable from user-data failure

---

# Release gate

Before considering iOS PWA text entry production-ready:

- [ ] all required field types pass on current supported iOS
- [ ] a fallback path exists for any deployment environment known to block native keyboard behavior
- [ ] campaign data can be exported manually
- [ ] Safari/PWA storage-transition behavior is documented
- [ ] save-schema migration test exists
- [ ] real-device test is part of release process
