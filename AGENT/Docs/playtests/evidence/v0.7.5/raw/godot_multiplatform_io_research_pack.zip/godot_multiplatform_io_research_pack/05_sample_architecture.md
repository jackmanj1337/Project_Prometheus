# Recommended Architecture & Code Notes

The objective is to keep platform checks out of game systems.

---

# 1. Autoload/service layout

Suggested autoloads or service nodes:

```text
/services
    save_store.gd
    external_file_io.gd
    text_entry_controller.gd
```

The game calls semantic methods:

```text
SaveStore.save_campaign(...)
SaveStore.load_campaign(...)

ExternalFileIO.import_file(...)
ExternalFileIO.export_file(...)

TextEntryController.begin_edit(...)
```

---

# 2. SaveStore

For ordinary internal saves, the implementation can usually remain platform-neutral.

```gdscript
class_name SaveStore

const SAVE_DIR := "user://saves"

func _ensure_save_dir() -> void:
    DirAccess.make_dir_recursive_absolute(SAVE_DIR)

func save_json(name: String, value: Variant) -> Error:
    _ensure_save_dir()

    var path := "%s/%s.json" % [SAVE_DIR, name]
    var file := FileAccess.open(path, FileAccess.WRITE)
    if file == null:
        return FileAccess.get_open_error()

    file.store_string(JSON.stringify(value))
    return OK

func load_json(name: String) -> Variant:
    var path := "%s/%s.json" % [SAVE_DIR, name]
    if not FileAccess.file_exists(path):
        return null

    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        return null

    return JSON.parse_string(file.get_as_text())
```

Use the same `user://` implementation on native Windows and Web unless a demonstrated requirement says otherwise.

Recommended additions for a real game:
- schema version
- atomic/temporary-write strategy
- backup slot
- checksum if useful
- migration functions
- autosave rotation

---

# 3. ExternalFileIO

Do not make callers depend on paths.

A portable result shape might be:

```gdscript
class_name ImportedFile

var name: String
var mime_type: String
var bytes: PackedByteArray
```

Game-facing API:

```gdscript
signal file_imported(file: ImportedFile)
signal import_cancelled
signal import_failed(message: String)

func request_import(accepted_types: PackedStringArray) -> void:
    if OS.has_feature("web"):
        _request_import_web(accepted_types)
    else:
        _request_import_native(accepted_types)
```

Native:
- show `FileDialog`
- read chosen file
- emit bytes

Web:
- trigger browser input picker through JavaScript
- receive selected file bytes
- emit the same `ImportedFile`

From the rest of the game:

```gdscript
func _on_map_imported(file: ImportedFile) -> void:
    MapImporter.import_bytes(file.bytes)
```

The map importer never cares whether the user picked:
- `C:\Maps\foo.json`
- an iOS Files document
- a browser-provided Blob

---

# 4. Web export helper

For export:

```gdscript
func export_bytes(
    data: PackedByteArray,
    suggested_name: String,
    mime_type: String
) -> void:
    if OS.has_feature("web"):
        JavaScriptBridge.download_buffer(
            data,
            suggested_name,
            mime_type
        )
        return

    _show_native_save_dialog(data, suggested_name)
```

Keep the request connected to a user action.

---

# 5. TextEntryController

The game should describe the requested edit semantically.

```gdscript
class_name TextEntryRequest

enum Kind {
    DEFAULT,
    NAME,
    EMAIL,
    PASSWORD,
    INTEGER,
    DECIMAL,
    PHONE,
    URL,
    CHAT,
    MULTILINE,
}

var kind := Kind.DEFAULT
var initial_text := ""
var placeholder := ""
var max_length := 0
var allow_cancel := true
```

Controller:

```gdscript
class_name TextEntryController

enum Backend {
    GODOT_CONTROL,
    GODOT_WEB_VIRTUAL_KEYBOARD,
    GODOT_ONSCREEN_KEYBOARD,
    CUSTOM_DOM,
}

var forced_backend: int = -1

func choose_backend(request: TextEntryRequest) -> Backend:
    if forced_backend >= 0:
        return forced_backend as Backend

    if OS.has_feature("web"):
        # Default Web path: ordinary Godot field plus the Web export's
        # experimental virtual keyboard support on touch devices.
        return Backend.GODOT_WEB_VIRTUAL_KEYBOARD

    return Backend.GODOT_CONTROL
```

The important point is not the exact enum. It is that **one module owns strategy selection**.

---

# 6. Field integration

A field can remain an ordinary `LineEdit`.

```gdscript
extends LineEdit

@export var entry_kind := TextEntryRequest.Kind.NAME

func _ready() -> void:
    focus_entered.connect(_on_focus_entered)

func _on_focus_entered() -> void:
    var request := TextEntryRequest.new()
    request.kind = entry_kind
    request.initial_text = text
    request.max_length = max_length

    TextEntryController.on_field_focused(self, request)
```

If the selected backend is the built-in Web VK, the controller may need to do little or nothing beyond policy/configuration.

If the selected backend is a custom Godot keyboard, the controller shows it and binds it to the active control.

If the selected backend is custom DOM, the controller starts the browser edit session.

---

# 7. Custom DOM bridge sketch

Only implement this if testing shows it is required.

GDScript side:

```gdscript
var _dom_commit_callback: JavaScriptObject

func _ready() -> void:
    if not OS.has_feature("web"):
        return

    _dom_commit_callback = JavaScriptBridge.create_callback(
        _on_dom_commit
    )

func begin_dom_edit(initial_text: String) -> void:
    var window := JavaScriptBridge.get_interface("window")
    if window == null:
        return

    # A function supplied by the custom HTML shell.
    window.godotTextEntryBegin(
        initial_text,
        _dom_commit_callback
    )

func _on_dom_commit(args: Array) -> void:
    var committed_text: String = str(args[0])
    # Update active field/game state.
```

HTML-shell side, conceptually:

```javascript
window.godotTextEntryBegin = function (initialText, callback) {
    const input = document.getElementById("godot-text-entry");
    input.value = initialText;
    input.hidden = false;
    input.focus();

    const finish = () => {
        callback(input.value);
        input.hidden = true;
    };

    // Wire a Done control / blur / key handling as appropriate.
};
```

A production implementation needs more careful callback lifetime, event cleanup, focus policy, viewport behavior, and composition handling.

---

# 8. Game-rendered keyboard integration

With a `Godot-Onscreen-Keyboard` style addon, prefer an event path like:

```text
keyboard button
    -> InputEventKey
    -> Input.parse_input_event()
    -> active LineEdit
```

rather than writing a separate text editor.

Add explicit policy so native and custom keyboards do not both activate.

Pseudo-policy:

```gdscript
func should_use_custom_onscreen_keyboard() -> bool:
    if not OS.has_feature("web"):
        return false

    # This can later be made capability/configuration based.
    return KnownEnvironmentWorkarounds.requires_web_keyboard_fallback()
```

---

# 9. Recommended project settings / export notes

For the Web export prototype:

- Enable PWA only for the PWA test preset.
- Enable `html/experimental_virtual_keyboard`.
- Keep a non-PWA Web preset if useful for browser-vs-installed comparisons.
- Keep native Windows as a separate export preset.
- Use the same test scene and save schema in all targets.

Recommended presets:

```text
Windows Native
Web Debug
Web PWA Test
Web PWA Release
```

---

# 10. Feature detection

Prefer capability or broad runtime checks to hard-coded device assumptions.

Examples:

```gdscript
if OS.has_feature("web"):
    # browser environment
```

For host-specific Web workarounds, Godot exposes feature tags including Web host variants such as iOS/Windows in current Godot versions. Verify the exact feature tags used by your target Godot version before depending on them in release logic.

Keep host-specific checks inside the service layer.

---

# 11. Suggested prototype scene

```text
MultiplatformIOTest
├── MarginContainer
│   └── VBoxContainer
│       ├── Label "Text Entry"
│       ├── LineEdit Name
│       ├── LineEdit Email
│       ├── LineEdit Password
│       ├── LineEdit Integer
│       ├── TextEdit Multiline
│       ├── HSeparator
│       ├── Label "Persistence"
│       ├── Button Save user://
│       ├── Button Load user://
│       ├── Label PersistenceStatus
│       ├── HSeparator
│       ├── Label "External Files"
│       ├── Button Import
│       ├── Button Export
│       └── Label Result
└── OnscreenKeyboard   # fallback backend, if installed
```

Display diagnostic values on screen:

```text
OS.get_name()
web feature?
web_ios feature?
web_windows feature?
userfs persistent?
PWA/browser mode if detectable?
last focus field
selected text backend
last save/load result
```

This makes real-device testing much faster.

---

# 12. Recommended implementation order

## Phase 1 — baseline

- `user://` JSON save
- standard LineEdit/TextEdit
- native Windows export
- ordinary Web export

## Phase 2 — PWA

- PWA preset
- iOS Home Screen install
- persistence tests
- built-in experimental virtual keyboard

## Phase 3 — external files

- Windows FileDialog
- Web import picker
- Web `download_buffer()` export

## Phase 4 — fallback keyboard

- integrate `Godot-Onscreen-Keyboard`
- route to it only in problem environments
- test field switching/caret behavior

## Phase 5 — only if required

- custom DOM text editor / custom HTML shell

This order minimizes custom platform code while leaving clear fallback points.
